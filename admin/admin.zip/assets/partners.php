<div class="section">
		<div class="content-wrap">
			<div class="container">
				<div class="row">

					<div class="col-lg-12 col-md-12">
						<h2 class="section-heading center">
							<span class="text-white">our</span> <span>Partners</span>
						</h2>
						<!-- <p class="subheading text-center">Lorem ipsum dolor sit amet, onsectetur adipiscing cons ectetur nulla. Sed at ullamcorper risus.</p> -->
					</div>
					
				</div>
				<div class="row gutter-5" align="center">
				<!-- 	<div class="col-6 col-md-2">
						<a href="#"><img src="images/dummy-img-200x125.jpg" alt="" class="img-fluid img-border"></a>
					</div>
					<div class="col-6 col-md-2">
						<a href="#"><img src="images/dummy-img-200x125.jpg" alt="" class="img-fluid img-border"></a>
					</div>
					<div class="col-6 col-md-2">
						<a href="#"><img src="images/dummy-img-200x125.jpg" alt="" class="img-fluid img-border"></a>
					</div>
					<div class="col-6 col-md-2">
						<a href="#"><img src="images/dummy-img-200x125.jpg" alt="" class="img-fluid img-border"></a>
					</div> -->
					<div class="col-6 col-md-2" align="center">
						<a href="#"><img src="images/dummy-img-200x125.jpg" alt="" class="img-fluid img-border"></a>
					</div>
					<div class="col-6 col-md-2" align="center">
						<a href="#"><img src="images/dummy-img2-200x125.jpg" alt="" class="img-fluid img-border"></a>
					</div>
					

				</div>
			</div>
		</div>
	</div>